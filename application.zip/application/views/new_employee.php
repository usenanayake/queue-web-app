<?php

echo 'cat';